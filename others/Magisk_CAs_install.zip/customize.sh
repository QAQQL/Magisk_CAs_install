#!/system/bin/sh

ui_print $MODPATH
ui_print "安装成功,重启手机后去系统证书查看是否生效."